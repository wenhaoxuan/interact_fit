from setuptools import setup, find_packages, version

setup(
    name = "interact_fit",
    version = '0.0.1',
    packages = find_packages()
)