# Interact Fit
Interactive data fitting code