# Interact Fit
Interactive data fitting code

See the example code in examples/example.py for how to use