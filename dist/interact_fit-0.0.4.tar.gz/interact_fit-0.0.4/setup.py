from setuptools import setup, find_packages, version

setup(
    name = "interact_fit",
    version = '0.0.4',
    packages = find_packages()
)